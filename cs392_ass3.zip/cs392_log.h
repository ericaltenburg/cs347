#ifndef CS392_LOG_H
#define CS392_LOG_H

#include <stdio.h>

void write_to_file(char *);
void empty_add();

#endif