#ifndef CS_392_EXEC_H
#define CS_392_EXEC_H

#include <stdio.h>
#include <signal.h>
#include <unistd.h>
#include <errno.h>

void execute(char *, size_t);
static void runs(int*, char**,int);


#endif