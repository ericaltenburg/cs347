/* 
 *	Michael McCreesh
 *  I pledge my honor that I have abided by the Stevens Honor System.
 *  CS392 Assignment3
 */

#include <stdlib.h>
#include "cs392_exec.h"
#include "cs392_log.h"
#include "cs392_signal.h"


int main() {
	char buffer[256];
	size_t len = 0;

	// Continually run, checking the input
    //print f returns the number of characters printed
    //non-zero values evaluate to true
	while(printf("cs392_shell $: ")){
        handlers();
        //without this it won't print the above line until exited
		fflush(stdout);
        //buffer is set to the input, len is number of bytes in buffer
		len = read(0, buffer, 255);
        //if negative number, it didn't read any bites
		if(len < 0) {
            if (errno == EINTR) { // check errno
				continue;
			} else {
				printf("Could not read input.\n");
				exit(1);
			}
		}
        else if(len == 1){// only enter w/o input -> add a new line to log and loop back to begining
            empty_add();
            continue;
        }
        else{// has actual input (len >1) -> execute
            // '\0' is the null termination symbol
            buffer[len-1] = '\0';
            // add command to the log
            write_to_file(buffer);
            // execute the command
            execute(buffer, len);
        }
	}

	return 0;
}