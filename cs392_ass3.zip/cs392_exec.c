/* 
 *	Michael McCreesh
 *  I pledge my honor that I have abided by the Stevens Honor System.
 *  CS392 Assignment3
 */

#include <stdio.h>
#include <stdlib.h>
#include <sys/wait.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include "cs392_exec.h"


static void runs(int pfd[], char** commands, int i) {
	int pid;

	switch (pid = fork()) {

	case 0: // Child
		dup2(pfd[i], i);
		if (i == 1){
			close(pfd[0]); 	
		}else{
			close(pfd[1]);
		}	
		execvp(commands[0], commands);	// run cmd
		perror(commands[0]);	// if it fails

	default: // Parent
		break;

	case -1:
		printf("Error: Could not properly fork.\n");
		exit(1);
	}
}

/*
 *	Executes the input, exits if given exit
 */
void execute(char * input, size_t len) {
	// Will hold the input commands
	char ** commands = malloc(256 * sizeof(char*));
	char ** pipes = malloc(256 * sizeof(char*));

	// iterates throuhh input
	size_t i = 0;
	//number of words
	int count = 1;
	//number of words after pipe
	int pipecount = 0;
	//is there a pipe? 1 = yes, 0 = no
	int has_pipe = 0;
	
	//traverse through the input
	while (i < len) { 
		if (input[i] == ' ') { // Another word
			count++;
			if(has_pipe == 1){
				pipecount++;
			}
		}
		if (input[i] == '|') { // There is a pipe
			has_pipe = 1;
		}
		i++;
	}


	for (i = 0; i < count; i++) { // fill with array for each word
		commands[i] = malloc(count * sizeof(char));
		if (has_pipe == 1) { // Populte the second array for each word you have if there is a pipe
			pipes[i] = malloc(count * sizeof(char));
		}
	}

	if(has_pipe == 1) { //if there is a pipe
 
		char * s = input;
		char * part; // Grabs the first part of command without pipe but includes space at the end
		char *array[2]; // Will hold the two parts of the command
		i = 0;
		while(part = strtok_r(s, "|", &s)) {
			array[i] = part;
            i++;
		}

        char* p1 = array[0];
		char * input1; // Grabs the first word in the string not the space between

		i = 0;
		while (input1  = strtok_r(p1, " ",&p1)) {
			if (strcmp(input1, "") == 0) { // There is a weird value from the part
				continue; 
			}
			strcpy(commands[i], input1); // Put the command in the array at specified index
			i++;
		}

		commands[i] = '\0';


		// THIS IS THE SECOND PART OF THE COMMAND 

		// Remove the initial space
		int l = strlen(array[1]);
		for (i = 0; i < l; i++) {
			array[1][i] = array[1][i+1];
		}

		// Push them onto the second command array
        s = array[1];
		char * input2;
		i = 0;
		while (input2  = strtok_r(s, " ", &s)) {
			strcpy(pipes[i], input2);
			i++;
		}

		pipes[i] = '\0';

		int pid, status;
		int fd[2];

		pipe(fd);

		runs(fd, commands, 1);
		runs(fd, pipes, 0);
		close(fd[0]);
		close(fd[1]);

		int b;
		while ((pid = wait(&status)) != -1)
			b = 0;

        for (int j = 0; j < count; j++) {
            free(commands[j]);
        }
        for (int j = 0; j < pipecount; j++) {
		    free(pipes[j]);
	    }

	} else { //the is no pipe
		char* s = input;
        char * input1;
		i = 0;
		while (input1  = strtok_r(s, " ",&s)) {
			// Place the input in the commands array
			strcpy(commands[i], input1);
			i++;
		}
		commands[i] = '\0';

		int pid1;

		if (strcmp(commands[0], "exit\0") == 0) { // exit was given, terminate
            for (int j = 0; j < count; j++) {
		        free(commands[j]);
	        }
	        free(commands);
			exit(0); // quit with no errors
		} else { // exit was not given
			pid1 = fork();
			if (pid1 < 0) {
				printf("Error: Could not properly fork.\n");
				for (int j = 0; j < count; j++) {
		            free(commands[j]);
	            }
				exit(1); // quit with error
			} else if (pid1 > 0) { // parent
				wait(NULL);
			} else { // child
				int check_valid;

				if ((check_valid = execvp(commands[0], commands) < 0)) { // Not a valid command
					printf("Command not found: %s.\n", commands[0]);
					for (int j = 0; j < count; j++) {
		                free(commands[j]);
	                }
					exit(1); // quit with error
				}
			}
		}
        for (int j = 0; j < count; j++) {
		    free(commands[j]);
	    }
	} 
    
}