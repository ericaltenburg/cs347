/* 
 *	Michael McCreesh
 *  I pledge my honor that I have abided by the Stevens Honor System.
 *  CS392 Assignment3
 */

#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <signal.h>
#include "cs392_signal.h"

//much of this file is from reference to slide #13 of the signal slides from week 9

/*
 *	Checks for SIGINT and SIGTSTP, then prints to show that the command was recieved
 */
void hdl(int sig, siginfo_t *siginfo, void *context) {
	if (sig == SIGINT) {
		printf(" Signal: %d. Enter exit to terminate process.\n", sig);
	}
	else if (sig == SIGTSTP) {
		printf(" Signal: %d. Enter exit to terminate process.\n", sig);
	}
}

/*
 *	Sets the flags then calls the functions to handle them
 */
int handlers() {
	struct sigaction act;

	memset(&act, '\0', sizeof(act));

	act.sa_sigaction = &hdl;
	act.sa_flags = SA_SIGINFO;

	if ((sigaction(SIGINT, &act, NULL) < 0) || (sigaction(SIGTSTP, &act, NULL) < 0)) {
		perror("Sigaction error.\n");
		return 1;
	}
	return 0;
}