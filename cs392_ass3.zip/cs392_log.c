/* 
 *	Michael McCreesh
 *  I pledge my honor that I have abided by the Stevens Honor System.
 *  CS392 Assignment3
 */

#include "cs392_log.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

void write_to_file(char * input) {
	FILE *fptr;
    //open the file to append. "a" is to append. data added to end of file
    fptr = fopen("cs392_shell.log", "a");

	if (fptr != NULL) { // go to new line and add input if no errors
		fprintf(fptr, "%s\n", input);
	} else { // but if there is an error say so
		perror("Error: Something went wrong.\n");
	}

	// Close the file
	fclose(fptr);
}

void empty_add() {
	FILE *fptr;
    //open the file to append. "a" is to append. data added to end of file
    fptr = fopen("cs392_shell.log", "a");

	if (fptr != NULL) { // go to new line if no errors
		fprintf(fptr, "\n");
	}
	 else { // but if there is an error say so
		perror("Error: Something went wrong.\n");
	}
	// Close the file
	fclose(fptr);
}